const express = require('express');
const router = express.Router();
const userController = require('../controllers/users');

router.get("/",(req,res)=> {
    //res.send("<h1>HIIIIII</h1>");
    res.render("index");
});

router.get("/home",(req,res) => {
    res.render("home");
});


router.get("/instructions",(req,res) => {
    res.render("instructions");
});

router.get("/qa",(req,res) => {
    res.render("qa");
});

router.get("/results",userController.isLoggedIn,(req,res) => {
    if (req.user){
        res.render("results",{user: req.user});
    }
    else{
        res.redirect("/index");
    }
});

module.exports = router;