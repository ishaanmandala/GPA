const express = require("express");
const userController = require('../controllers/users');
const router = express.Router();

router.post('/index',userController.index);
router.post('/home',userController.home);

//router.post('/results',userController.results);




//router.post('/login',userController.login);
//router.get('/logout',userController.logout);

module.exports = router;